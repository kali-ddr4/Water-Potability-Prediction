# Water-Quality-Prediction
A machine learning based project in which water quality index (WQI) and quality status of water is predicted through some parameters that affects water quality.<br>
The theoretical explanation of the project is in the uploaded pdf and rest the coding part is explained in the Jupyter notebook itself. 
